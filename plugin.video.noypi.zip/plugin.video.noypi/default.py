import urllib2 , urllib , xbmcgui , xbmcplugin , xbmc , re , sys , os , xbmcaddon
import urlresolver
from addon . common . addon import Addon
import requests
oo000 = requests . session ( )
ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
oOOo = 'plugin.video.noypi'
O0 = xbmcaddon . Addon ( id = oOOo )
o0O = Addon ( oOOo , sys . argv )
iI11I1II1I1I = O0 . getAddonInfo ( 'name' )
oooo = xbmcaddon . Addon ( )
iIIii1IIi = oooo . getAddonInfo ( 'path' )
o0OO00 = oooo . getAddonInfo ( 'icon' )
oo = oooo . getAddonInfo ( 'fanart' )
i1iII1IiiIiI1 = 'NOYPI'
iIiiiI1IiI1I1 = oooo . getAddonInfo ( 'version' )
o0OoOoOO00 = iIIii1IIi + "/resources/icons/"
if 27 - 27: OOOo0 / Oo - Ooo00oOo00o . I1IiI
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
def O0oOO0o0 ( ) :
 i1ii1iIII ( '[B][COLOR white]KAPUSO[/COLOR][/B]' , 'http://www.kapuso.me/search/label/GMA?&max-results=24' , 5 , o0OoOoOO00 + 'kapus.jpg' , oo , '' )
 i1ii1iIII ( '[B][COLOR white]KAPAMILYA[/COLOR][/B]' , 'http://pacitalaflakes.blogspot.com/search/label/ABS-CBN?m=0' , 5 , o0OoOoOO00 + 'tamb.jpg' , oo , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 59 - 59: II1i * o00ooo0 / o00 * Oo0oO0ooo
def o0oOoO00o ( url ) :
 i1 = oOOoo00O0O ( url )
 i1111 = re . compile ( "<a class='thumbx' href='(.+?)' title='(.+?)'.+?src='(.+?)'/></a>" , re . DOTALL ) . findall ( i1 )
 for url , i11 , I11 in i1111 :
  i11 = i11 . replace ( '&#8217;' , '\'' ) . replace ( '&#8211;' , '-' ) . replace ( '&#39;' , '\'' ) . replace ( '&amp;#038;' , '&' )
  I11 = I11 . replace ( 's72-c/' , '' )
  i1ii1iIII ( '[B][COLOR white]%s[/COLOR][/B]' % i11 , url , 10 , I11 , oo , '' )
 Oo0o0000o0o0 = re . compile ( "<a class='blog-pager-older-link' href='(.+?)'" , re . DOTALL ) . findall ( i1 )
 for url in Oo0o0000o0o0 :
  if 'kapuso' in url :
   I11 = o0OoOoOO00 + ''
  if 'pacitalaflakes' in url :
   I11 = o0OoOoOO00 + ''
  i1ii1iIII ( '[B][COLOR yellow]Next Page ===>>[/COLOR][/B]' , url , 5 , I11 , oo , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 86 - 86: iiiii11iII1 % O0o
def oO0 ( name , url ) :
 i1 = oOOoo00O0O ( url )
 i1111 = re . compile ( '<[iI][fF][rR][aA][mM][eE] [sS][rR][cC]="(.+?)"' , re . DOTALL ) . findall ( i1 )
 for url in i1111 :
  try :
   IIIi1i1I = url . split ( '//' ) [ 1 ] . replace ( 'www.' , '' )
   IIIi1i1I = IIIi1i1I . split ( '/' ) [ 0 ] . split ( '.' ) [ 0 ] . title ( )
  except : pass
  i1ii1iIII ( '[B][COLOR white]%s[/COLOR][/B]' % IIIi1i1I , url , 100 , OOoOoo00oo , oo , name )
 iiI11 = re . compile ( 'DM.player.+?"player(.+?)".+?video: "(.+?)"' , re . DOTALL ) . findall ( i1 )
 for IIIi1i1I , url in iiI11 :
  i1ii1iIII ( '[B][COLOR white]Part %s[/COLOR][/B]' % IIIi1i1I , 'http://www.dailymotion.com/embed/video/%s' % url , 100 , OOoOoo00oo , oo , name )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 91 - 91: oOOOO / i1iiIII111ii + iiIIi1IiIi11 . i1Ii
def I111I11 ( url ) :
 try :
  if 'speedvid.net' in url :
   i1 = oOOoo00O0O ( url )
   O0O00Ooo = re . compile ( 'primary\|8777\|.+?primary\|(.+?)\|(.+?)\|.+?image\|mp4\|(.+?)\|' , re . DOTALL ) . findall ( i1 )
   for OOoooooO , i1iIIIiI1I , hash in O0O00Ooo :
    url = 'http://' + i1iIIIiI1I + '.speedvid.net:' + OOoooooO + '/' + hash + '/v.mp4'
   OOoO000O0OO = url
  else :
   OOoO000O0OO = urlresolver . resolve ( url )
  iiI1IiI = xbmcgui . ListItem ( i11 , iconImage = "DefaultVideo.png" , thumbnailImage = OOoOoo00oo )
  iiI1IiI . setInfo ( type = "Video" , infoLabels = { "Title" : II } )
  iiI1IiI . setProperty ( "IsPlayable" , "true" )
  iiI1IiI . setPath ( OOoO000O0OO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiI1IiI )
 except : pass
 if 57 - 57: o00
def iI ( ) :
 iI11iiiI1II = [ ]
 O0oooo0Oo00 = sys . argv [ 2 ]
 if len ( O0oooo0Oo00 ) >= 2 :
  Ii11iii11I = sys . argv [ 2 ]
  oOo00Oo00O = Ii11iii11I . replace ( '?' , '' )
  if ( Ii11iii11I [ len ( Ii11iii11I ) - 1 ] == '/' ) :
   Ii11iii11I = Ii11iii11I [ 0 : len ( Ii11iii11I ) - 2 ]
  iI11i1I1 = oOo00Oo00O . split ( '&' )
  iI11iiiI1II = { }
  for o0o0OOO0o0 in range ( len ( iI11i1I1 ) ) :
   ooOOOo0oo0O0 = { }
   ooOOOo0oo0O0 = iI11i1I1 [ o0o0OOO0o0 ] . split ( '=' )
   if ( len ( ooOOOo0oo0O0 ) ) == 2 :
    iI11iiiI1II [ ooOOOo0oo0O0 [ 0 ] ] = ooOOOo0oo0O0 [ 1 ]
 return iI11iiiI1II
 if 71 - 71: iiIIi1IiIi11 . Oo
def oOOoo00O0O ( url ) :
 o0OO0oo0oOO = { }
 o0OO0oo0oOO [ 'User-Agent' ] = ii
 O0O00Ooo = oo000 . get ( url , headers = o0OO0oo0oOO ) . text
 O0O00Ooo = O0O00Ooo . encode ( 'ascii' , 'ignore' )
 return O0O00Ooo
 if 54 - 54: OoOO % ii11ii1ii % ii11ii1ii
def i1ii1iIII ( name , url , mode , iconimage , fanart , description ) :
 iI1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 i11Iiii = True
 iiI1IiI = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iiI1IiI . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iiI1IiI . setProperty ( 'fanart_image' , fanart )
 if mode == 100 :
  iiI1IiI . setProperty ( "IsPlayable" , "true" )
  i11Iiii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1 , listitem = iiI1IiI , isFolder = False )
 else :
  i11Iiii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1 , listitem = iiI1IiI , isFolder = True )
 return i11Iiii
 if 23 - 23: II1i . ii11ii1ii
 if 98 - 98: Ooo00oOo00o % o00O0oo * o00ooo0 * o00O0oo
Ii11iii11I = iI ( )
i1IiIiiI = None
i11 = None
I1I = None
OOoOoo00oo = None
II = None
if 80 - 80: o00O0oo - o0000oOoOoO0o
if 87 - 87: o00 / iiiii11iII1 - OOooOOo * Oo0oO0ooo / I1IiI . Oo
if 1 - 1: ii11ii1ii - iiiii11iII1 / iiiii11iII1
if 46 - 46: O0o * Oo0oO0ooo - o0000oOoOoO0o * o00 - iiIIi1IiIi11
try :
 i1IiIiiI = urllib . unquote_plus ( Ii11iii11I [ "url" ] )
except :
 pass
try :
 i11 = urllib . unquote_plus ( Ii11iii11I [ "name" ] )
except :
 pass
try :
 OOoOoo00oo = urllib . unquote_plus ( Ii11iii11I [ "iconimage" ] )
except :
 pass
try :
 I1I = int ( Ii11iii11I [ "mode" ] )
except :
 pass
try :
 II = urllib . unquote_plus ( Ii11iii11I [ "description" ] )
except :
 pass
 if 83 - 83: I1IiI
if I1I == None or i1IiIiiI == None or len ( i1IiIiiI ) < 1 : O0oOO0o0 ( )
elif I1I == 5 : o0oOoO00o ( i1IiIiiI )
elif I1I == 10 : oO0 ( i11 , i1IiIiiI )
elif I1I == 100 : I111I11 ( i1IiIiiI )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 31 - 31: ii11ii1ii - Oo0oO0ooo . iiIIi1IiIi11 % o00O0oo - Oo
if 4 - 4: ii11ii1ii / i1Ii . oOOOO
if 58 - 58: Oo0oO0ooo * OOOo0 / o00O0oo % iiIIi1IiIi11 - o00ooo0 / o00
if 50 - 50: OoOO
if 34 - 34: OoOO * ii11ii1ii % oOOOO * o00O0oo - OoOO
if 33 - 33: II1i + Oo0oO0ooo * o0000oOoOoO0o - OoOO0ooOOoo0O / o00 % O0o
if 21 - 21: o0000oOoOoO0o * Ooo00oOo00o % o00 * OOooOOo
if 16 - 16: Oo - iiIIi1IiIi11 * Ooo00oOo00o + oOOOO
if 50 - 50: ii11ii1ii - i1Ii * o00ooo0 / iiIIi1IiIi11 + II1i
if 88 - 88: O0o / iiIIi1IiIi11 + oOOOO - ii11ii1ii / i1Ii - o00O0oo
if 15 - 15: o00ooo0 + o00O0oo - I1IiI / Oo0oO0ooo
if 58 - 58: OOOo0 % iiiii11iII1
if 71 - 71: Oo0oO0ooo + i1Ii % OOOo0 + o00ooo0 - i1iiIII111ii
if 88 - 88: o00O0oo - o0000oOoOoO0o % Oo0oO0ooo
if 16 - 16: OoOO * o00 % i1iiIII111ii
if 86 - 86: OoOO + O0o % OOOo0 * o00 . i1Ii * iiiii11iII1
if 44 - 44: o00
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
